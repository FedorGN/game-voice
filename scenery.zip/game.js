const stage = document.querySelector("#stage");
const canvas = document.querySelector("#field");
const ctx = canvas.getContext("2d");
const overlay = document.querySelector("#overlay");
const screens = {
  menu: document.querySelector("#intro"),
  connecting: document.querySelector("#setup"),
  calibrating: document.querySelector("#setup"),
  ready: document.querySelector("#ready"),
  paused: document.querySelector("#paused"),
  over: document.querySelector("#game-over"),
};
const scoreLabel = document.querySelector("#score");
const recordLabel = document.querySelector("#record");
const pauseButton = document.querySelector("#pause");
const micStatus = document.querySelector("#mic-status");
const micError = document.querySelector("#mic-error");
const sensitivity = document.querySelector("#sensitivity");
const sensitivityValue = document.querySelector("#sensitivity-value");
const meterFill = document.querySelector("#meter-fill");
const meterThreshold = document.querySelector("#meter-threshold");
const calibrateButton = document.querySelector("#calibrate");
const deviceField = document.querySelector("#device-field");
const deviceSelect = document.querySelector("#microphone");
const progress = document.querySelector("#calibration-progress");
const voiceButton = document.querySelector("#start-voice");
const retryButton = document.querySelector("#retry");
const resumeButton = document.querySelector("#resume");

const MOTH_RADIUS = 15;
const FLAP_VELOCITY = -282;
const GRAVITY = 720;
const CALIBRATION_TIME = 1.6;
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const formatScore = (score) => String(score).padStart(2, "0");

function readNumber(key, fallback, max) {
  try {
    const value = localStorage.getItem(key);
    const number = Number(value);
    return value !== null && Number.isInteger(number) && number >= 0 && number <= max
      ? number
      : fallback;
  } catch {
    return fallback;
  }
}

function storeNumber(key, number) {
  try {
    localStorage.setItem(key, String(number));
  } catch {
    // Private or restricted pages can still play with session-only settings.
  }
}

let phase = "menu";
let mode = "keyboard";
let width = 840;
let best = readNumber("night-flight-record", 0, Number.MAX_SAFE_INTEGER);
let run;
let microphone = null;
let microphoneRequest = 0;
let selectedDevice = "";
let calibration = null;
let noiseFloor = .006;
let sensitivityAmount = readNumber("night-flight-sensitivity", 65, 100);
let voiceGate;
let waveformTime = 0;

function resetVoiceGate() {
  voiceGate = { armed: false, loudFor: 0, quietFor: 0, cooldown: 0 };
}

function thresholds() {
  const headroom = .014 + .085 * (1 - sensitivityAmount / 100) ** 1.8;
  const trigger = noiseFloor + Math.max(headroom, noiseFloor * .38);
  return { trigger, release: noiseFloor + (trigger - noiseFloor) * .53 };
}

function meterPosition(level) {
  const decibels = 20 * Math.log10(Math.max(level, .001));
  return clamp((decibels + 60) / 52, 0, 1) * 100;
}

function drawSensitivity() {
  sensitivity.value = String(sensitivityAmount);
  sensitivityValue.value = `${sensitivityAmount}%`;
  meterThreshold.style.left = `${meterPosition(thresholds().trigger)}%`;
}

function setMicStatus(message, kind = "off") {
  micStatus.textContent = message;
  micStatus.dataset.kind = kind;
}

function showMicError(message = "") {
  micError.textContent = message;
  micError.hidden = message === "";
  if (message) setMicStatus("Недоступен", "error");
}

function setPhase(next) {
  phase = next;
  stage.dataset.phase = next;
  overlay.hidden = next === "playing";
  pauseButton.hidden = next !== "playing";
  Object.values(screens).forEach((screen) => { screen.hidden = screen !== screens[next]; });

  const active = next === "calibrating" || next === "ready" || next === "playing";
  if (microphone) {
    microphone.stream.getAudioTracks().forEach((track) => { track.enabled = active; });
    if (!active) meterFill.style.width = "0%";
  }
  const adjustable = microphone !== null && (next === "ready" || next === "over");
  calibrateButton.disabled = !adjustable;
  deviceSelect.disabled = !adjustable;

  if (next === "connecting") setMicStatus("Подключение");
  else if (next === "calibrating") setMicStatus("Калибровка", "on");
  else if (microphone) setMicStatus(active ? "Слушает" : "На паузе", active ? "on" : "off");
  else setMicStatus("Выключен");
}

function resetRun() {
  run = {
    elapsed: 0,
    score: 0,
    moth: { x: mothX(), y: FIELD_HEIGHT * .49, velocity: 0 },
    gates: [],
    particles: [],
  };
  scoreLabel.textContent = formatScore(0);
}

function mothX() {
  return Math.min(151, width * .27);
}

function resizeField() {
  const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
  const bounds = canvas.getBoundingClientRect();
  if (bounds.height < 1 || bounds.width < 1) return;
  canvas.width = Math.round(bounds.width * pixelRatio);
  canvas.height = Math.round(bounds.height * pixelRatio);
  width = canvas.width / canvas.height * FIELD_HEIGHT;
  const scale = canvas.height / FIELD_HEIGHT;
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  run.moth.x = mothX();
  drawField(ctx, width, phase, run, waveformTime);
}

function releaseMicrophone() {
  microphoneRequest += 1;
  calibration = null;
  if (microphone) {
    const { stream, context } = microphone;
    microphone = null;
    stream.getTracks().forEach((track) => track.stop());
    if (context.state !== "closed") void context.close().catch(() => {});
  }
  meterFill.style.width = "0%";
  deviceField.hidden = true;
}

function returnToMenu({ focus = true } = {}) {
  releaseMicrophone();
  showMicError();
  resetRun();
  setPhase("menu");
  if (focus) voiceButton.focus({ preventScroll: true });
}

function prepareFlight(inputMode) {
  mode = inputMode;
  resetRun();
  resetVoiceGate();
  document.querySelector("#ready-title").textContent =
    mode === "voice" ? "Один звук — один взмах" : "Готов к полёту?";
  document.querySelector("#ready-description").textContent =
    mode === "voice" ? "Скажи короткое «м», чтобы начать." : "Нажми пробел или коснись поля.";
  setPhase("ready");
}

function startKeyboard() {
  releaseMicrophone();
  showMicError();
  prepareFlight("keyboard");
}

function microphoneError(error) {
  switch (error?.name) {
    case "NotAllowedError":
    case "SecurityError":
      return "Разреши микрофон в настройках сайта и попробуй снова.";
    case "NotFoundError":
    case "OverconstrainedError":
      return "Микрофон не найден. Подключи его или выбери другое устройство.";
    case "NotReadableError":
    case "AbortError":
      return "Не удалось открыть микрофон. Проверь доступ в системе и попробуй снова.";
    default:
      return "Не удалось подключить микрофон. Можно играть пробелом или тапом.";
  }
}

async function updateDevices(request) {
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    if (request !== microphoneRequest || !microphone) return;
    const inputs = devices.filter(({ kind, deviceId }) =>
      kind === "audioinput" && deviceId && deviceId !== "default" && deviceId !== "communications"
    );
    deviceSelect.replaceChildren(new Option("Системный микрофон", ""));
    inputs.forEach((device, index) => {
      deviceSelect.add(new Option(device.label || `Микрофон ${index + 1}`, device.deviceId));
    });
    deviceSelect.value = inputs.some((device) => device.deviceId === selectedDevice) ? selectedDevice : "";
    deviceField.hidden = inputs.length === 0;
  } catch {
    if (request === microphoneRequest) deviceField.hidden = true;
  }
}

async function startVoice(deviceId = selectedDevice) {
  releaseMicrophone();
  showMicError();
  const Audio = window.AudioContext || window.webkitAudioContext;
  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia || !Audio) {
    showMicError("Для голосового режима открой игру через localhost или HTTPS в браузере с доступом к микрофону.");
    return;
  }

  const request = microphoneRequest;
  document.querySelector("#setup-title").textContent = "Подключаем микрофон";
  document.querySelector("#setup-description").textContent = "Разреши доступ к микрофону в браузере.";
  progress.hidden = true;
  resetRun();
  setPhase("connecting");
  let stream;
  let context;
  try {
    context = new Audio();
    // Start audio in the same user gesture that requests permission.
    const resumed = context.resume();
    void resumed.catch(() => {});
    const input = { autoGainControl: false, noiseSuppression: true, echoCancellation: true };
    if (deviceId) input.deviceId = { exact: deviceId };
    stream = await navigator.mediaDevices.getUserMedia({ audio: input });
    if (request !== microphoneRequest) {
      stream.getTracks().forEach((track) => track.stop());
      await context.close();
      return;
    }
    await resumed;
    if (request !== microphoneRequest) {
      stream.getTracks().forEach((track) => track.stop());
      await context.close();
      return;
    }
    const analyser = context.createAnalyser();
    analyser.fftSize = 1024;
    context.createMediaStreamSource(stream).connect(analyser);
    microphone = { stream, context, analyser, samples: new Float32Array(analyser.fftSize) };
    selectedDevice = deviceId;
    stream.getAudioTracks().forEach((track) => {
      track.addEventListener("ended", () => {
        if (microphone?.stream !== stream) return;
        returnToMenu({ focus: false });
        selectedDevice = "";
        showMicError("Микрофон отключился. Подключи его снова или играй пробелом.");
      });
    });
    beginCalibration();
    void updateDevices(request);
  } catch (error) {
    stream?.getTracks().forEach((track) => track.stop());
    if (context && context.state !== "closed") void context.close().catch(() => {});
    if (request !== microphoneRequest) return;
    selectedDevice = "";
    returnToMenu();
    showMicError(microphoneError(error));
  }
}

function beginCalibration() {
  if (!microphone) return;
  calibration = { levels: [], elapsed: 0 };
  document.querySelector("#setup-title").textContent = "Измеряем фоновый шум";
  document.querySelector("#setup-description").textContent = "Помолчи пару секунд.";
  progress.value = 0;
  progress.hidden = false;
  setPhase("calibrating");
}

function micLevel() {
  const { analyser, samples } = microphone;
  analyser.getFloatTimeDomainData(samples);
  let sumSquares = 0;
  for (const sample of samples) sumSquares += sample * sample;
  return Math.sqrt(sumSquares / samples.length);
}

function updateVoice(delta) {
  if (!microphone || !["calibrating", "ready", "playing"].includes(phase)) return;
  const level = micLevel();
  meterFill.style.width = `${meterPosition(level)}%`;
  if (calibration) {
    calibration.elapsed += delta;
    calibration.levels.push(level);
    progress.value = Math.min(1, calibration.elapsed / CALIBRATION_TIME);
    if (calibration.elapsed >= CALIBRATION_TIME) {
      const sorted = calibration.levels.sort((a, b) => a - b);
      noiseFloor = clamp(sorted[Math.floor(sorted.length * .7)], .003, .32);
      calibration = null;
      drawSensitivity();
      prepareFlight("voice");
    }
    return;
  }

  const { trigger, release } = thresholds();
  voiceGate.cooldown = Math.max(0, voiceGate.cooldown - delta);
  if (level <= release) {
    voiceGate.quietFor += delta;
    if (voiceGate.quietFor >= .09 && voiceGate.cooldown === 0) voiceGate.armed = true;
  } else {
    voiceGate.quietFor = 0;
  }
  voiceGate.loudFor = level >= trigger ? voiceGate.loudFor + delta : 0;
  if (voiceGate.armed && voiceGate.loudFor >= .035) {
    voiceGate.armed = false;
    voiceGate.loudFor = 0;
    voiceGate.cooldown = .18;
    flap();
  }
}

function addGate(x) {
  const difficulty = Math.min(1, run.score / 35);
  const previous = run.gates.at(-1);
  const center = previous
    ? clamp(previous.center + (Math.random() - .5) * 190, 168, 395)
    : FIELD_HEIGHT / 2;
  run.gates.push({ x, center, gap: 204 - 35 * difficulty, phase: Math.random() * Math.PI * 2, scored: false });
}

function fillCourse() {
  if (run.gates.length === 0) addGate(Math.min(width + 37, run.moth.x + 395));
  while (run.gates.at(-1).x < width + 32) {
    addGate(run.gates.at(-1).x + 285 + Math.random() * 48);
  }
}

function flap() {
  if (phase === "ready") {
    fillCourse();
    setPhase("playing");
  }
  if (phase !== "playing") return;
  run.moth.velocity = FLAP_VELOCITY;
  for (let n = 0; n < 7; n++) {
    run.particles.push({
      x: run.moth.x + (Math.random() - .5) * 14,
      y: run.moth.y + (Math.random() - .5) * 15,
      dx: -54 - Math.random() * 110,
      dy: (Math.random() - .36) * 65,
      life: .28 + Math.random() * .31,
      size: 1 + Math.random() * 1.65,
    });
  }
}

function circleHitsBox(moth, left, top, right, bottom) {
  const x = moth.x - clamp(moth.x, left, right);
  const y = moth.y - clamp(moth.y, top, bottom);
  return x * x + y * y <= MOTH_RADIUS * MOTH_RADIUS;
}

function hitLanterns(moth, pose) {
  const { x, top, bottom } = pose;
  return (
    circleHitsBox(moth, x - 4, 0, x + 4, top - LANTERN_HEIGHT) ||
    circleHitsBox(moth, x - LANTERN_WIDTH, top - LANTERN_HEIGHT, x + LANTERN_WIDTH, top) ||
    circleHitsBox(moth, x - LANTERN_WIDTH, bottom, x + LANTERN_WIDTH, bottom + LANTERN_HEIGHT) ||
    circleHitsBox(moth, x - 7.5, bottom + LANTERN_HEIGHT, x + 7.5, FIELD_HEIGHT)
  );
}

function finishFlight() {
  document.querySelector("#final-score").textContent = formatScore(run.score);
  document.querySelector("#final-record").textContent = formatScore(best);
  setPhase("over");
  retryButton.focus({ preventScroll: true });
}

function updateFlight(delta) {
  run.elapsed += delta;
  const { moth } = run;
  moth.velocity += GRAVITY * delta;
  moth.y += moth.velocity * delta;
  if (moth.y <= 19 + MOTH_RADIUS || moth.y >= FIELD_HEIGHT - 23 - MOTH_RADIUS) {
    finishFlight();
    return;
  }
  const speed = 178 + Math.min(70, run.score * 2.6);
  for (const gate of run.gates) {
    gate.x -= speed * delta;
    const pose = gatePose(gate, run.elapsed);
    if (hitLanterns(moth, pose)) {
      finishFlight();
      return;
    }
    if (!gate.scored && gate.x + LANTERN_WIDTH + MOTH_RADIUS + 8 < moth.x) {
      gate.scored = true;
      run.score += 1;
      scoreLabel.textContent = formatScore(run.score);
      if (run.score > best) {
        best = run.score;
        recordLabel.textContent = formatScore(best);
        storeNumber("night-flight-record", best);
      }
    }
  }
  if (run.gates[0].x < -60) run.gates.shift();
  fillCourse();
  for (const particle of run.particles) {
    particle.x += particle.dx * delta;
    particle.y += particle.dy * delta;
    particle.life -= delta;
  }
  run.particles = run.particles.filter((particle) => particle.life > 0);
}

function togglePause() {
  if (phase === "playing") {
    setPhase("paused");
    resumeButton.focus({ preventScroll: true });
  } else if (phase === "paused") {
    resetVoiceGate();
    setPhase("playing");
  }
}

voiceButton.addEventListener("click", () => { void startVoice(); });
document.querySelector("#start-keyboard").addEventListener("click", startKeyboard);
document.querySelector("#launch").addEventListener("click", flap);
document.querySelector("#cancel-setup").addEventListener("click", () => returnToMenu());
document.querySelector("#quit-paused").addEventListener("click", () => returnToMenu());
document.querySelector("#quit-over").addEventListener("click", () => returnToMenu());
pauseButton.addEventListener("click", togglePause);
resumeButton.addEventListener("click", togglePause);
retryButton.addEventListener("click", () => prepareFlight(mode));
calibrateButton.addEventListener("click", beginCalibration);
deviceSelect.addEventListener("change", () => { void startVoice(deviceSelect.value); });
sensitivity.addEventListener("input", () => {
  sensitivityAmount = Number(sensitivity.value);
  storeNumber("night-flight-sensitivity", sensitivityAmount);
  resetVoiceGate();
  drawSensitivity();
});

stage.addEventListener("pointerdown", (event) => {
  if (event.button === 0 && event.isPrimary && !event.target.closest("button")) flap();
});

document.addEventListener("keydown", (event) => {
  if (event.repeat || event.target.closest?.("input, select, textarea")) return;
  if (event.code === "Escape" && (phase === "playing" || phase === "paused")) {
    event.preventDefault();
    togglePause();
  } else if (event.code === "Space" && !event.target.closest?.("button")) {
    event.preventDefault();
    if (phase === "menu") startKeyboard();
    flap();
  }
});

document.addEventListener("visibilitychange", () => {
  if (document.hidden && phase === "playing") togglePause();
});
window.addEventListener("pagehide", () => returnToMenu({ focus: false }));

recordLabel.textContent = formatScore(best);
drawMothEmblem(document.querySelector("#brand-moth"), .65);
drawMothEmblem(document.querySelector("#intro-moth"), 1.73);
drawSensitivity();
resetRun();
resetVoiceGate();
setPhase("menu");
resizeField();
new ResizeObserver(resizeField).observe(stage);

let previousFrame = performance.now();
function frame(now) {
  const delta = clamp((now - previousFrame) / 1000, 0, .045);
  previousFrame = now;
  waveformTime = now / 1000;
  updateVoice(delta);
  if (phase === "playing") updateFlight(delta);
  drawField(ctx, width, phase, run, waveformTime);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
